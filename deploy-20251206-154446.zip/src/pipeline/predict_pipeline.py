import sys 
import pandas as pd 
from src.components.exception import CustomException
from src.components.logger import logging
from src.components.utils import load_object
from src.components.model_trainer import ModelTrainer
import dill

class PredictPipeline:
    def __init__(self):
        pass 

    def predict(self, features):
        try:
            logging.info("Loading preprocessor and model objects")
            preprocessor_path = 'artifacts/preprocessor.pkl'
            model_path = 'artifacts/model.pkl'
            preprocessor = load_object(preprocessor_path)
            model = load_object(model_path)

            logging.info("Transforming input features")
            data_scaled = preprocessor.transform(features)

            logging.info("Making predictions")
            preds = model.predict(data_scaled)
            return preds
        except Exception as e:
            logging.info("Exception occurred during prediction")
            raise CustomException(e, sys)

class CustomData: 
    def __init__(self,
        gender: str,
        race_ethnicity: str,
        parental_level_of_education: str,
        lunch: str,
        test_preparation_course: str,
        reading_score: float,
        writing_score: float): 

        self.gender = gender 
        self.race_ethnicity = race_ethnicity
        self.parental_level_of_education = parental_level_of_education
        self.lunch = lunch
        self.test_preparation_course = test_preparation_course
        self.reading_score = reading_score
        self.writing_score = writing_score

    def get_data_as_data_frame(self):
        try:
            custom_data_input_dict = { 
                "gender": [self.gender],
                "race_ethnicity": [self.race_ethnicity],
                "parental_level_of_education": [self.parental_level_of_education],
                "lunch": [self.lunch], 
                "test_preparation_course": [self.test_preparation_course],
                "reading_score": [self.reading_score],
                "writing_score": [self.writing_score]
            }
            return pd.DataFrame(custom_data_input_dict)
        except Exception as e:
            raise CustomException(e, sys)
